If you are reading this then make sure you don't delete anything in any of the files, folders, etc.
Deleting anything could potentially break the datapack
Make sure if you use this anywhere else to give credit to me, Zorra.
And Have Fun playing with this pack